package org.mykola.kindershop2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kindershop2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
