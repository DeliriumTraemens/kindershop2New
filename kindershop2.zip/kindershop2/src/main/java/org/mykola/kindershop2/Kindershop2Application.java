package org.mykola.kindershop2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kindershop2Application {

	public static void main(String[] args) {
		SpringApplication.run(Kindershop2Application.class, args);
	}

}
